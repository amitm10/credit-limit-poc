package com.poc.credit.api.service;

import com.poc.credit.api.config.CreditProperties;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

/**
 * Redis replication is asynchronous, so a primary can acknowledge a reservation and die
 * before its replica has it. WAIT narrows that window: it returns once N replicas confirm
 * this connection's writes, or after the timeout. A timeout is counted and logged but does
 * not fail the check; after a failover the processor replays Kafka to recover anything lost.
 * Must be called inside the same Redis session as the write (see CreditCheckService).
 */
@Component
public class ReplicaWaiter {

    private static final Logger log = LoggerFactory.getLogger(ReplicaWaiter.class);

    private final StringRedisTemplate redis;
    private final CreditProperties props;
    private final Counter timeouts;

    public ReplicaWaiter(StringRedisTemplate redis, CreditProperties props, MeterRegistry registry) {
        this.redis = redis;
        this.props = props;
        this.timeouts = Counter.builder("credit.redis.wait.timeouts")
                .description("Reservations not confirmed by a replica within the WAIT timeout")
                .register(registry);
    }

    public void awaitReplication() {
        int replicas = props.waitReplicas();
        if (replicas <= 0) {
            return;
        }
        Object acked = redis.execute((RedisCallback<Object>) connection -> connection.execute("WAIT",
                bytes(replicas), bytes(props.waitTimeout().toMillis())));
        if (!(acked instanceof Long count) || count < replicas) {
            timeouts.increment();
            log.debug("WAIT timed out: {} of {} replicas confirmed", acked, replicas);
        }
    }

    private static byte[] bytes(long value) {
        return Long.toString(value).getBytes(StandardCharsets.UTF_8);
    }
}
